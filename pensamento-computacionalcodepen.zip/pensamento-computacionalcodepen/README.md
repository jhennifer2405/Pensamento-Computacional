# pensamento computacional- CodePen 

A Pen created on CodePen.io. Original URL: [https://codepen.io/jhennifer2405/pen/xxWQpZr](https://codepen.io/jhennifer2405/pen/xxWQpZr).

